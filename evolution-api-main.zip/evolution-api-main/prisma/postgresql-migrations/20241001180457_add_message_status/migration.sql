-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "status" INTEGER;
