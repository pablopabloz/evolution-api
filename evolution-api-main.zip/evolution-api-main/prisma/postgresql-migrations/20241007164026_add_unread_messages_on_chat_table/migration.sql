-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "unreadMessages" INTEGER NOT NULL DEFAULT 0;
