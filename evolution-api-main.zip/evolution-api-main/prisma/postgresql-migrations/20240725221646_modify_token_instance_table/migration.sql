-- DropIndex
DROP INDEX "Instance_token_key";
