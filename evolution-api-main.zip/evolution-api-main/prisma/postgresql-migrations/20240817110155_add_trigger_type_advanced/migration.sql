-- AlterEnum
ALTER TYPE "TriggerType" ADD VALUE 'advanced';
